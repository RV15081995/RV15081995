package com.greatlearning.java.service;

import java.util.Random;

import com.greatlearning.java.model.Employee;

public class CredentialService {
	String email;
	String password;
	public String emailGenerator(String firstName,String lastName,String dept){		
		email=firstName+lastName+"@"+dept+".abc.com";
		return email;
	}
	
	public char[] passwordGenerator(){
		char[] password_generated=new char[8];
		String capitalLetters="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String smallLetters="abcdefghijklmnopqrstuvwxyz";
		String numbers="0123456789";
		String specialchars="!@#$%^&*?<>";
		
		String values =capitalLetters+smallLetters+numbers+specialchars;
		
		Random random=new Random();
		
		for (int i=0;i<8;i++)
		{
			password_generated[i]=values.charAt(random.nextInt(values.length()));
		}
		return password_generated;
	}
	public void showCredentials(Employee employee,String email,char[] generatedpassword){
		System.out.println("Dear "+employee.getFirstName()+".Your generated credentials are as follows");
		System.out.println("Email --> "+email);
		System.out.print("Password -->");
		System.out.println(generatedpassword);
	}

}
