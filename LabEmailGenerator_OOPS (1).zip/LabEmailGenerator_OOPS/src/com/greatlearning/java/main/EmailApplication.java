package com.greatlearning.java.main;

import java.util.Scanner;

import com.greatlearning.java.model.Employee;
import com.greatlearning.java.service.CredentialService;

public class EmailApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String firstName;
		String lastName;
		int deptNo;
		String email;
		char[] password;
		
		
		CredentialService credential=new CredentialService();
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome!!");
		System.out.println("Please enter your First Name");
		firstName=sc.next();
		System.out.println("Please enter your Last Name");
		lastName=sc.next();
		Employee employee=new Employee(firstName,lastName);
		
		
		System.out.println("Please select your Department Num from options below");
		System.out.println("1. Technical");
		System.out.println("2. Admin");
		System.out.println("3. Human Resource");
		System.out.println("4. Legal");
		deptNo=sc.nextInt();
		
		switch(deptNo) {
			case 1:
				email=credential.emailGenerator(employee.getFirstName().toLowerCase(),employee.getLastName().toLowerCase(),"tech");
				password=credential.passwordGenerator();
				credential.showCredentials(employee,email,password);
				break;
				
			case 2:
				email=credential.emailGenerator(employee.getFirstName().toLowerCase(),employee.getLastName().toLowerCase(),"admin");
				password=credential.passwordGenerator();
				credential.showCredentials(employee,email,password);
				break;
			case 3:
				email=credential.emailGenerator(employee.getFirstName().toLowerCase(),employee.getLastName().toLowerCase(),"hr");
				password=credential.passwordGenerator();
				credential.showCredentials(employee,email,password);
				break;
			case 4:	
				email=credential.emailGenerator(employee.getFirstName().toLowerCase(),employee.getLastName().toLowerCase(),"legal");
				password=credential.passwordGenerator();
				credential.showCredentials(employee,email,password);
				break;
			default:
				System.out.println("Please select valid Dept No");
			
	}
		sc.close();

}
}

